1) Don't delete any files. This software isn't that smart yet.

2) You might need Java installed:
https://www.oracle.com/technetwork/java/javase/downloads/jdk13-downloads-5672538.html

3) Have fun